//
//  NFHybridConfigInfo.h
//  NewsFeedsHybridSDK
//
//  Created by Jingjq on 2018/5/15.
//

#import <Foundation/Foundation.h>

@interface NFHybridConfigInfo : NSObject

///频道Tag。自定义 无频道导航栏样式 时需传入展示的channelTag。可从CMS后台获取
@property (nonatomic, copy) NSString *channelTag;

@end
